package com.example.avocadox.bookmark

import androidx.lifecycle.ViewModel

class BookmarkViewModel: ViewModel() {
    var bookmarkComment = ""
}
