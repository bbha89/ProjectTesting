package com.example.avocadox.profile

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.AdapterView
import android.widget.ImageView
import android.widget.ListView
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModelProvider
import com.example.avocadox.R
import com.example.avocadox.Util
import java.io.File

class CatProfileActivity : AppCompatActivity(){
    private lateinit var profileViewModel: ProfileViewModel
    private lateinit var cameraResult: ActivityResultLauncher<Intent>
    private lateinit var imageView: ImageView

    // Profile photo
    private val imageFileName="profile_photo.jpg"
    private val tmpImageFileName="tmp_profile_photo.jpg"
    private val dataFileName="name.txt"
    private lateinit var imageFile: File
    private lateinit var tmpImageFile: File
    private lateinit var imageUri: Uri
    private lateinit var tmpImageUri: Uri

    private lateinit var dataFile: File

    private lateinit var myListView: ListView
    private val optionList = arrayOf(
        "User name", "Category", "Gender", "Age",
        "Weight", "Pet's food", "Love experience"
    )

    private val drawableImgList = arrayOf(
        R.drawable.username,R.drawable.category,
        R.drawable.gender,R.drawable.age,
        R.drawable.weight,R.drawable.pet_food,
        R.drawable.love_experience
    )

    private lateinit var myListAdapter: MyListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_cat)
        Util.checkPermissions(this)
        myListView = findViewById(R.id.myListView)

        myListAdapter = MyListAdapter(this, optionList, drawableImgList)
        myListView.adapter = myListAdapter

        imageView = findViewById(R.id.imageProfile)

        // Initialize files
        imageFile = File(getExternalFilesDir(null), imageFileName)
        tmpImageFile = File(getExternalFilesDir(null), tmpImageFileName)
        dataFile = File(getExternalFilesDir(null), dataFileName)

        // Get image URI
        imageUri = FileProvider.getUriForFile(this, "com.example.avocadox.profile", imageFile)
        tmpImageUri = FileProvider.getUriForFile(this, "com.example.avocadox.profile", tmpImageFile)

        // Get a reference to the image saved on the device if it exists
        if (imageFile.exists()) {
            val bitmap = Util.getBitmap(this, imageUri)
            imageView.setImageBitmap(bitmap)
        }

        // Update the view layer upon change
        profileViewModel = ViewModelProvider(this).get(ProfileViewModel::class.java)
        profileViewModel.image.observe(this) {
            val bitmap = Util.getBitmap(this, tmpImageUri)
            imageView.setImageBitmap(bitmap)
        }

        cameraResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                // Pass the captured picture to the ViewModel layer
                val bitmap = Util.getBitmap(this, tmpImageUri)
                profileViewModel.image.value = bitmap
            }
        }

        myListView.setOnItemClickListener { parent: AdapterView<*>, textView: View, position: Int, id: Long->
            val myDialog = DialogFragment()
            val bundle = Bundle()
            if (id.toString() == "0") {
                bundle.putInt(DialogFragment.DIALOG_KEY, DialogFragment.USERNAME_DIALOG)
            } else if (id.toString() == "1") {
                bundle.putInt(DialogFragment.DIALOG_KEY, DialogFragment.CATEGORY_DIALOG)
            } else if (id.toString() == "2") {
                bundle.putInt(DialogFragment.DIALOG_KEY, DialogFragment.GENDER_DIALOG)
            } else if (id.toString() == "3") {
                bundle.putInt(DialogFragment.DIALOG_KEY, DialogFragment.AGE_DIALOG)
            } else if (id.toString() == "4") {
                bundle.putInt(DialogFragment.DIALOG_KEY, DialogFragment.WEIGHT_DIALOG)
            } else if (id.toString() == "5") {
                bundle.putInt(DialogFragment.DIALOG_KEY, DialogFragment.PET_FOOD_DIALOG)
            } else if (id.toString() == "6") {
                bundle.putInt(DialogFragment.DIALOG_KEY, DialogFragment.LOVE_EXPERIENCE_DIALOG)
            }

            myDialog.arguments = bundle
            myDialog.show(supportFragmentManager, "tag")
        }

    }

    fun onChangePhotoClicked(view: View) {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.putExtra(MediaStore.EXTRA_OUTPUT, tmpImageUri)
        cameraResult.launch(intent)
    }
}