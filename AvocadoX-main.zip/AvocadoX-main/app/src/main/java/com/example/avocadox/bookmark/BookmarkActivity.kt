package com.example.avocadox.bookmark

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.avocadox.R

class BookmarkActivity : AppCompatActivity() {
    private lateinit var bookmarkLocation: TextView
    private lateinit var bookmarkComment: EditText
    private lateinit var bookmarkSaveButton: Button
    private lateinit var bookmarkCancelButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bookmark)

        bookmarkLocation = findViewById(R.id.bookmark_location)
        //      TODO: Get location info from Map

        bookmarkComment = findViewById(R.id.bookmark_comment_input)

        bookmarkSaveButton = findViewById(R.id.bookmark_save_button)
        bookmarkSaveButton.setOnClickListener {
            Log.d("BookmarkActivity", "Save button clicked")
            //      TODO: save location and comment/review

            Toast.makeText(this, "Bookmark saved", Toast.LENGTH_LONG).show()
            finish()
        }

        bookmarkCancelButton = findViewById(R.id.bookmark_cancel_button)
        bookmarkCancelButton.setOnClickListener {
            Log.d("BookmarkActivity", "Cancel button clicked")
            finish()
        }
    }
}