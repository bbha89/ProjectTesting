package com.example.avocadox.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.navigation.fragment.findNavController
import com.example.avocadox.R
import com.example.avocadox.databinding.FragmentSampleBinding

//Sample fragment to demonstrate data binding

class SampleFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val binding: FragmentSampleBinding = DataBindingUtil.inflate(
            inflater, R.layout.fragment_sample, container, false)

        binding.sampleText.text = "Value set using data binding"
        binding.textVariable = "Assigning a value to data binding variable"

        binding.button.setOnClickListener {
            //This is to navigate from SampleFragment to NavigateSampleFragment (this id is created when we dragged an arrow from one fragment to another)
            findNavController().navigate(R.id.action_sampleFragment_to_navigateSampleFragment)
        }

        return binding.root
    }
}