package com.example.avocadox

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.databinding.DataBindingUtil
import com.example.avocadox.bookmark.BookmarkActivity
import com.example.avocadox.yourWalk.YourWalkActivity
import com.example.avocadox.databinding.ActivityMainBinding
import com.example.avocadox.profile.CatProfileActivity

class MainActivity : AppCompatActivity() {

    private lateinit var bookmarkButton: Button
    private lateinit var yourWalkButton: Button
    private lateinit var catProfileButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding: ActivityMainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        navigateToBookmarkAndYourWalk()

    }

    private fun navigateToBookmarkAndYourWalk() {
        // Temporary buttons for bookmark and your_walk
        // So that I can test them when running the app
        bookmarkButton = findViewById(R.id.nav_to_bookmark_button)
        bookmarkButton.setOnClickListener {
            val intent = Intent(this, BookmarkActivity::class.java)
            startActivity(intent)
        }

        yourWalkButton = findViewById(R.id.nav_to_your_walk_button)
        yourWalkButton.setOnClickListener {
            val intent = Intent(this, YourWalkActivity::class.java)
            startActivity(intent)
        }

        catProfileButton = findViewById(R.id.nav_to_cat_profile)
        catProfileButton.setOnClickListener {
            val intent = Intent(this, CatProfileActivity::class.java)
            startActivity(intent)
        }
    }





}