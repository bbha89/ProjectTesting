package com.example.avocadox.profile

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.example.avocadox.R

class MyListAdapter(private val context: Activity, private val setting_options: Array<String>, private val drawableIds: Array<Int>) : BaseAdapter(){
    override fun getCount(): Int {
        return setting_options.size
    }

    override fun getItem(position: Int): Any {
        return setting_options[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, view: View?, parent: ViewGroup?): View {
        val view = View.inflate(context, R.layout.listview_manual, null)

        val imgIcon = view.findViewById<ImageView>(R.id.imgIcon)
        val textView = view.findViewById<TextView>(R.id.textview)

        imgIcon.setImageResource(drawableIds[position])
        textView.text = setting_options[position]

        return view
    }

}
