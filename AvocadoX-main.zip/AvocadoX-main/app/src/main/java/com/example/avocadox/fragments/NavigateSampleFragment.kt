package com.example.avocadox.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.navigation.fragment.findNavController
import com.example.avocadox.R
import com.example.avocadox.databinding.FragmentNavigateSampleBinding

class NavigateSampleFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val binding: FragmentNavigateSampleBinding = DataBindingUtil.inflate(
            inflater, R.layout.fragment_navigate_sample, container, false)

        binding.button2.setOnClickListener {
            //This is to navigate from NavigateSampleFragment to SampleFragment (this id is created when we dragged an arrow from one fragment to another)
            findNavController().navigate(R.id.action_navigateSampleFragment_to_sampleFragment)

            //or we can use this to go back (pop back up - like the back button)
            //findNavController().popBackStack()
        }

        return binding.root
    }
}