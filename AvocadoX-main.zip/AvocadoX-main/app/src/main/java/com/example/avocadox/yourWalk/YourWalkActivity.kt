package com.example.avocadox.yourWalk

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.*
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.avocadox.R
import com.example.avocadox.Util
import java.lang.reflect.InvocationTargetException

class YourWalkActivity : AppCompatActivity() {

    private lateinit var yourDistanceText : TextView
    private lateinit var emotionHappyImg : ImageView
    private lateinit var emotionMehImg : ImageView
    private lateinit var emotionSadImg : ImageView
    private lateinit var walkImg : ImageView
    private lateinit var walkComment : EditText
    private lateinit var saveButton : Button
    private lateinit var addImgButton : Button

    private lateinit var galleryResult: ActivityResultLauncher<Intent>
    private lateinit var yourWalkViewModel: YourWalkViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_your_walk)

        yourWalkViewModel = ViewModelProvider(this).get(
            YourWalkViewModel::class.java
        )

//      TODO: Get user name and pet user/pet profile
//      TODO: Get current location from Map

        yourDistanceText = findViewById(R.id.your_walk_distance)
        yourDistanceText.text = "Nice job, AvocadoX! You and ... walked ... Miles!"
        walkComment = findViewById(R.id.your_walk_comment_input)

        emotionImgHelper()
        walkImgHelper()
        saveHelper()
    }

    private fun emotionImgHelper() {
        emotionHappyImg = findViewById(R.id.emotion_happy)
        emotionHappyImg.setBackgroundResource(R.drawable.emotion_happy_background);
        emotionHappyImg.setOnClickListener {
            yourWalkViewModel.emotion = 0
            Log.d("YourWalkActivity", "emotion set to 0, HAPPY")
        }

        emotionMehImg = findViewById(R.id.emotion_meh)
        emotionMehImg.setBackgroundResource(R.drawable.emotion_meh_background);
        emotionMehImg.setOnClickListener {
            yourWalkViewModel.emotion = 1
            Log.d("YourWalkActivity", "emotion set to 1, MEH")
        }

        emotionSadImg = findViewById(R.id.emotion_sad)
        emotionSadImg.setBackgroundResource(R.drawable.emotion_sad_background);
        emotionSadImg.setOnClickListener {
            yourWalkViewModel.emotion = 2
            Log.d("YourWalkActivity", "emotion set to 2, SAD")
        }
    }

    private fun walkImgHelper() {
        walkImg = findViewById(R.id.walk_img)

        galleryResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult())
        { it: ActivityResult ->
            if (it.resultCode == Activity.RESULT_OK) {
                Log.d("Gallery Result", "RESULT_OK")
                try {
                    val data: Intent? = it.data
                    if (data != null) {
                        Log.d("Gallery Result", "data: $data")
                        val selectedUri = data.data
                        Log.d("Gallery Result", "selected uri: $selectedUri")
                        if (selectedUri != null) {
                            val bitmap = Util.getBitmap(this, selectedUri)
                            yourWalkViewModel.yourWalkImg.value = bitmap
                            walkImg.setImageBitmap(bitmap)
                        }
                    }
                } catch (exception: InvocationTargetException) {
                    Log.d("Gallery Result", exception.toString())
                }
//                    this.dismiss()
            }
        }

        addImgButton = findViewById(R.id.your_walk_add_img_button)
        addImgButton.setOnClickListener {
            Log.d("YourWalkActivity", "Opening gallery to select image")
            val intent: Intent
            try {
                intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
                intent.type = "image/*"
                intent.action = Intent.ACTION_GET_CONTENT
                Intent.createChooser(intent, "Select Picture")
                galleryResult.launch(intent)
            } catch (exception: InvocationTargetException) {
                Log.d("InvocationTargetException", exception.toString())
            }
        }
    }

    private fun saveHelper() {
        saveButton = findViewById((R.id.your_walk_save_button))
        saveButton.setOnClickListener {
            Log.d("YourWalkActivity", "Save button clicked")
            // save emotion
            // save comment
            // save miles, location, etc
            Toast.makeText(this, "SAVE Clicked", Toast.LENGTH_LONG).show()
            finish()
        }
    }
}
