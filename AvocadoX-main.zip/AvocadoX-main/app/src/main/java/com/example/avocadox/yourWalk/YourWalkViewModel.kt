package com.example.avocadox.yourWalk

import android.graphics.Bitmap
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class YourWalkViewModel: ViewModel() {
    var emotion = -1
    var yourWalkImg = MutableLiveData<Bitmap>()
}