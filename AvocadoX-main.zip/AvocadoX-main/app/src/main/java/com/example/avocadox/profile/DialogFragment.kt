package com.example.avocadox.profile

import android.app.AlertDialog
import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.EditText
import androidx.fragment.app.DialogFragment
import com.example.avocadox.R
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar

class DialogFragment: DialogFragment(), DialogInterface.OnClickListener  {
    companion object {
        const val USERNAME_DIALOG = 0
        const val CATEGORY_DIALOG = 1
        const val GENDER_DIALOG = 2
        const val AGE_DIALOG = 3
        const val WEIGHT_DIALOG = 4
        const val PET_FOOD_DIALOG = 5
        const val LOVE_EXPERIENCE_DIALOG = 6
        const val DIALOG_KEY = "key"
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        lateinit var dialog: Dialog
        val bundle = arguments
        val builder = AlertDialog.Builder(requireActivity())

        if(bundle?.getInt(DIALOG_KEY) == USERNAME_DIALOG) {
            val input = EditText(requireActivity())
            input.inputType = InputType.TYPE_CLASS_TEXT
            builder.setTitle("Select Username")
            .setView(input)
            .setPositiveButton("ok", this)
            .setNegativeButton("cancel", this)
            dialog = builder.create()
        } else if(bundle?.getInt(DIALOG_KEY) == CATEGORY_DIALOG) {
            var selectedItemIndex = 0
            val breedList = arrayOf("American Shorthair", "Bengal", "Exotic", "Japanese Bobtail", "Persian")
            var selectedBreed = breedList[selectedItemIndex]
            MaterialAlertDialogBuilder(requireActivity())
            builder.setTitle("Select Breed")
                .setSingleChoiceItems(breedList, selectedItemIndex) {dialog, which ->
                    selectedItemIndex = which
                    selectedBreed = breedList[which]
                }
                .setPositiveButton("OK", this)
                .setNegativeButton("Cancel",this)
            dialog = builder.create()
        } else if(bundle?.getInt(DIALOG_KEY) == GENDER_DIALOG) {
            var selectedItemIndex = 0
            val genderList = arrayOf("Male", "Female")
            var selectedGender = genderList[selectedItemIndex]
            MaterialAlertDialogBuilder(requireActivity())
            builder.setTitle("Select Gender")
            .setSingleChoiceItems(genderList, selectedItemIndex) {dialog, which ->
                    selectedItemIndex = which
                    selectedGender = genderList[which]
                }
            .setPositiveButton("OK", this)
            .setNegativeButton("Cancel",this)
            dialog = builder.create()
        } else if(bundle?.getInt(DIALOG_KEY) == AGE_DIALOG) {
            val input = EditText(requireActivity())
            input.inputType = InputType.TYPE_CLASS_NUMBER
            builder.setTitle("Enter Age")
                .setView(input)
                .setPositiveButton("ok",this)
                .setNegativeButton("cancel", this)
            dialog = builder.create()
        } else if(bundle?.getInt(DIALOG_KEY) == WEIGHT_DIALOG) {
            val input = EditText(requireActivity())
            input.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            builder.setTitle("Enter Weight")
                .setView(input)
                .setPositiveButton("ok",this)
                .setNegativeButton("cancel", this)
            dialog = builder.create()
        } else if(bundle?.getInt(DIALOG_KEY) == PET_FOOD_DIALOG) {
            val input = EditText(requireActivity())
            input.inputType = InputType.TYPE_CLASS_TEXT
            builder.setTitle("Enter Pet Food")
                .setView(input)
                .setPositiveButton("ok", this)
                .setNegativeButton("cancel", this)
            dialog = builder.create()
        } else if(bundle?.getInt(DIALOG_KEY) == LOVE_EXPERIENCE_DIALOG) {
            var selectedItemIndex = 0
            val loveExperienceList = arrayOf("Child", "First time in love", "experienced in loving", "Professional Dad")
            var selectedloveExperience = loveExperienceList[selectedItemIndex]
            MaterialAlertDialogBuilder(requireActivity())
            builder.setTitle("Select Gender")
                .setSingleChoiceItems(loveExperienceList, selectedItemIndex) {dialog, which ->
                    selectedItemIndex = which
                    selectedloveExperience = loveExperienceList[which]
                }
                .setPositiveButton("OK", this)
                .setNegativeButton("Cancel",this)
            dialog = builder.create()
        }
        return dialog
    }

    override fun onClick(dialog: DialogInterface?, which: Int) {
    }
}